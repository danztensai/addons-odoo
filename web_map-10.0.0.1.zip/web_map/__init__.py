﻿# -*- coding: utf-8 -*-
##############################################################################
#
#    Odoo
#    Copyright (C) 2017 CodUP (<http://codup.com>).
#
##############################################################################

import models

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: